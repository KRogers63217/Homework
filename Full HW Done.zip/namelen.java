import java.util.Scanner;
public class namelen{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter name: ");
        String name = input.nextLine();
        
        System.out.println(name.length());
        
        System.out.println("Enter Postcode: ");
        String post = input.nextLine();
        System.out.println(post.toUpperCase());
        
        System.out.println("Enter password: ");
        String pass1 = input.nextLine();
        
        System.out.println("Enter password again: ");
        String pass2 = input.nextLine();
        if (pass1.equals(pass2)){
            System.out.println("Password Verified");
               }
        else {
    System.out.println("Access denied m8");
        }
    
    System.out.println("Enter your name: ");
    name = input.nextLine();
    System.out.println("Hello " + name.substring(name.indexOf(" ")+1,name.length()));
    
    
}


    
	private static int indexof(String string) {
		// TODO Auto-generated method stub
		return 0;
	}
}
