import java.util.Scanner;
public class Vowels {
	public static void main (String[] args){
		Scanner input = new Scanner(System.in);
		String text1;
		System.out.println("Enter Words ");
		text1 = input.nextLine();
		text1 = text1.toLowerCase();
		int vowels = 0;
		int cons = 0;
		for (int i = 0; i < text1.length(); i++){
			char ch = text1.charAt(i);
			if (ch =='a' || ch =='e' || ch =='i' || ch =='o' || ch =='u' ){
				vowels++;
			}
			else{
				cons++;
			}
		}
		System.out.println("Vowels: " + vowels + " " + "Consonants: " + cons);
	}
}
