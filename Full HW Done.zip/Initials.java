import java.util.Scanner;
public class Initials {
	public static void main (String[] args){
		Scanner imput = new Scanner(System.in);
		System.out.println("Enter your name: ");
		String name = imput.nextLine();
		System.out.println(name.substring(0,1) + name.substring(name.indexOf(" ")+1,name.indexOf(" ")+2)) + name.substring(name.indexOf(" ",name.indexOf(" ")+1)+1,name.indexOf(" ",name.indexOf(" ")+2)+2);
	}
}
