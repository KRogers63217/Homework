import java.util.Scanner;
public class Split {
	public static void main (String[] args){
		Scanner imput = new Scanner (System.in);
		System.out.println("Enter the phrase: ");
		String text = imput.nextLine();
		System.out.println(text.split(" ").length);
	}
}
