import java.util.Scanner;
public class Reverse {
	public static void main (String[] args){
		Scanner imput = new Scanner (System.in);
		System.out.println("Enter words: ");
		String text = imput.nextLine();
		for (int i = text.length() - 1; i >= 0; i--){
			System.out.println(text.charAt(i));
		}
	}
}
